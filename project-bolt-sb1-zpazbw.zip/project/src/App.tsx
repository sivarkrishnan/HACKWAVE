import React, { useState } from 'react';
import {
  Leaf,
  Bus,
  Train,
  Car,
  Bike,
  TreePine,
  Droplets,
  Lightbulb,
  Menu,
  X,
} from 'lucide-react';
import { DashboardCard } from './components/DashboardCard';
import { Challenge } from './components/Challenge';
import { TransportOption } from './components/TransportOption';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Leaf className="h-8 w-8 text-emerald-600" />
              <span className="ml-2 text-xl font-semibold text-gray-800">EcoTrack</span>
            </div>
            
            {/* Mobile menu button */}
            <div className="flex items-center md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-500 hover:text-gray-600"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>

            {/* Desktop navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#dashboard" className="text-emerald-600 font-medium">Dashboard</a>
              <a href="#transport" className="text-gray-500 hover:text-gray-700">Transport</a>
              <a href="#challenges" className="text-gray-500 hover:text-gray-700">Challenges</a>
              <button className="bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors">
                Track Activity
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="pt-2 pb-3 space-y-1">
              <a href="#dashboard" className="block px-4 py-2 text-emerald-600 font-medium">Dashboard</a>
              <a href="#transport" className="block px-4 py-2 text-gray-500">Transport</a>
              <a href="#challenges" className="block px-4 py-2 text-gray-500">Challenges</a>
              <button className="block w-full text-left px-4 py-2 bg-emerald-600 text-white">
                Track Activity
              </button>
            </div>
          </div>
        )}
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Section */}
        <section id="dashboard" className="mb-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Your Impact Dashboard</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <DashboardCard
              title="Carbon Footprint"
              value="2.4 tons"
              icon={<Leaf className="h-6 w-6" />}
              trend="down"
              trendValue="12% this month"
            />
            <DashboardCard
              title="Trees Saved"
              value="47"
              icon={<TreePine className="h-6 w-6" />}
            />
            <DashboardCard
              title="Water Saved"
              value="234L"
              icon={<Droplets className="h-6 w-6" />}
            />
          </div>
        </section>

        {/* Transport Section */}
        <section id="transport" className="mb-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Sustainable Transport Options</h2>
          <div className="space-y-4">
            <TransportOption
              icon={<Bus className="h-5 w-5" />}
              mode="Bus Route 42"
              time="25 min"
              emissions="0.3 kg CO₂"
              route="Central Station → Green Park"
            />
            <TransportOption
              icon={<Train className="h-5 w-5" />}
              mode="Metro Line B"
              time="15 min"
              emissions="0.1 kg CO₂"
              route="City Center → Suburb Station"
            />
            <TransportOption
              icon={<Bike className="h-5 w-5" />}
              mode="Bike Share"
              time="20 min"
              emissions="0 kg CO₂"
              route="Main Street → Park Avenue"
            />
          </div>
        </section>

        {/* Challenges Section */}
        <section id="challenges">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Green Challenges</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Challenge
              title="Zero Waste Week"
              description="Minimize your waste production for 7 days"
              participants={342}
              daysLeft={5}
              completed={true}
            />
            <Challenge
              title="Energy Saver"
              description="Reduce your energy consumption by 20%"
              participants={156}
              daysLeft={12}
            />
            <Challenge
              title="Public Transport Hero"
              description="Use only public transport for commuting"
              participants={89}
              daysLeft={3}
            />
            <Challenge
              title="Local Food Challenge"
              description="Eat only locally sourced food for a week"
              participants={234}
              daysLeft={8}
            />
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center">
                <Leaf className="h-6 w-6 text-emerald-600" />
                <span className="ml-2 text-lg font-semibold text-gray-800">EcoTrack</span>
              </div>
              <p className="mt-2 text-sm text-gray-500">
                Making sustainable choices easier for everyone.
              </p>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-800 mb-4">Quick Links</h3>
              <ul className="space-y-2 text-sm text-gray-500">
                <li><a href="#dashboard" className="hover:text-emerald-600">Dashboard</a></li>
                <li><a href="#transport" className="hover:text-emerald-600">Transport</a></li>
                <li><a href="#challenges" className="hover:text-emerald-600">Challenges</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-800 mb-4">Connect</h3>
              <ul className="space-y-2 text-sm text-gray-500">
                <li>contact@ecotrack.com</li>
                <li>Twitter: @ecotrack</li>
                <li>Instagram: @ecotrack.green</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t text-center text-sm text-gray-500">
            © 2024 EcoTrack. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;