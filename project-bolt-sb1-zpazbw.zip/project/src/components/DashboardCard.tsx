import React from 'react';

interface DashboardCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: 'up' | 'down';
  trendValue?: string;
}

export function DashboardCard({ title, value, icon, trend, trendValue }: DashboardCardProps) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-gray-600 text-sm font-medium">{title}</h3>
        <div className="text-emerald-600">{icon}</div>
      </div>
      <div className="flex items-end justify-between">
        <p className="text-2xl font-bold text-gray-800">{value}</p>
        {trend && (
          <p className={`text-sm ${trend === 'down' ? 'text-emerald-600' : 'text-red-500'} flex items-center`}>
            {trend === 'down' ? '↓' : '↑'} {trendValue}
          </p>
        )}
      </div>
    </div>
  );
}