import React from 'react';
import { Trophy } from 'lucide-react';

interface ChallengeProps {
  title: string;
  description: string;
  participants: number;
  daysLeft: number;
  completed?: boolean;
}

export function Challenge({ title, description, participants, daysLeft, completed }: ChallengeProps) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-all cursor-pointer border-2 border-transparent hover:border-emerald-100">
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="font-semibold text-gray-800 mb-1">{title}</h3>
          <p className="text-sm text-gray-600">{description}</p>
        </div>
        <Trophy className={`w-6 h-6 ${completed ? 'text-yellow-400' : 'text-gray-300'}`} />
      </div>
      <div className="flex items-center justify-between mt-4 text-sm">
        <p className="text-emerald-600">👥 {participants} joined</p>
        <p className="text-gray-500">{daysLeft} days left</p>
      </div>
    </div>
  );
}