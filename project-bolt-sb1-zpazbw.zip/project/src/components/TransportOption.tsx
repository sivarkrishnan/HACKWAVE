import React from 'react';

interface TransportOptionProps {
  icon: React.ReactNode;
  mode: string;
  time: string;
  emissions: string;
  route: string;
}

export function TransportOption({ icon, mode, time, emissions, route }: TransportOptionProps) {
  return (
    <div className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer">
      <div className="flex items-center gap-4">
        <div className="p-3 bg-emerald-50 rounded-lg text-emerald-600">
          {icon}
        </div>
        <div className="flex-1">
          <h3 className="font-medium text-gray-800">{mode}</h3>
          <p className="text-sm text-gray-500">{route}</p>
        </div>
        <div className="text-right">
          <p className="font-medium text-gray-800">{time}</p>
          <p className="text-sm text-emerald-600">{emissions}</p>
        </div>
      </div>
    </div>
  );
}